保存候选方案的environment.txt、metrics.json与Trace。
