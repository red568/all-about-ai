保存冻结基线的environment.txt、metrics.json与Trace。
