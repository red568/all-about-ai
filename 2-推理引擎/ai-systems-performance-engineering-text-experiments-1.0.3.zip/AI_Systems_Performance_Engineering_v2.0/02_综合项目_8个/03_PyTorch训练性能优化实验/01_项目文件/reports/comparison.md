# PyTorch训练性能对照报告

## 环境与等价条件

记录输入形状、有效Batch Size、随机种子、数据顺序、精度、编译模式和硬件环境。

## 对照结果

| 方案 | P50 Step ms | P95 Step ms | Samples/s | Peak MiB | Final Loss | Valid Step Ratio |
|---|---:|---:|---:|---:|---:|---:|
| Baseline |  |  |  |  |  |  |
| Candidate |  |  |  |  |  |  |

## 正确性、收益与边界

解释损失差异、性能变化来源、冷启动影响、Graph Break及适用边界。
