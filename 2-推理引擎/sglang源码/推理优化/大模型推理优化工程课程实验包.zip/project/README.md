# 综合项目

每个编号目录都是独立实验，只需进入对应目录查看 `README.md` 和运行 `run.py`。

- `run.py`：默认运行 Fixture；加 `--real` 才进入真实 CUDA 或端点路径。
- `requirements.txt`：本类实验的依赖说明。
- 内部运行库已并入各自的 `run.py`，压缩包不再暴露构建脚本、测试、清单或源码库目录。

## 目录

- `01-speculator-benchmark/` — Project 01：Next-Generation Speculator Benchmark
- `02-workload-platform/` — Project 02：Heterogeneous Inference Workload Benchmark Platform
- `03-smart-router/` — Project 03：Production AI Gateway and Smart Router
- `04-multitenant-lora/` — Project 04：Multi-Tenant, Multi-Model and Multi-LoRA Serving
- `05-fleet-planner/` — Project 05：GPU Fleet Planner and SLA-Aware Autoscaler
- `06-inference-platform/` — Project 06：Production LLM Inference Platform
