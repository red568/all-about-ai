# Project 02：Heterogeneous Inference Workload Benchmark Platform

按到达时间重放 Reasoning、Agentic、Structured、Multimodal 与 Compound 五类工作流，并分别核算端到端 SLO。

这个目录只有一个入口 `run.py`。所需的底层运行库已经合并到入口中，不需要寻找或复制其他源码目录。

## 运行

从压缩包根目录执行：

```bash
python project/02-workload-platform/run.py --check-only
python project/02-workload-platform/run.py --output results/project-02-workload-platform-fixture.json
python project/02-workload-platform/run.py --real --base-url http://127.0.0.1:8000 --workload data/project02_workload.jsonl \
  --output results/gpu_result.json
```

不带 `--real` 时运行确定性 Fixture，只验证控制逻辑。真实前置条件不足时输出 `status=precondition_failed` 并以退出码 2 结束，不会回退到 CPU 冒充实测。

## 输入

- GPU-backed endpoint
- five-kind workload JSONL
- multimodal fixture

## 输出

- per-kind metrics
- SLO violations
- subcall lineage
- metrics snapshots

## 验收

- all five handlers run
- arrival order is preserved
- structured output is validated
- compound/agentic paths make multiple linked calls

只有 `source=measured` 的报告可以用于性能或发布结论。API Key 只从 `OPENAI_API_KEY` 读取。
